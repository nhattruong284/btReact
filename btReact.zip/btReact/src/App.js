import logo from './logo.svg';
import './App.css';
import BaiTapThucHanh from './Components/BaiTapThucHanhLayout/BaiTapThucHanh';

function App() {
  return (
    <div className="App">
      <BaiTapThucHanh />
    </div>
  );
}

export default App;
